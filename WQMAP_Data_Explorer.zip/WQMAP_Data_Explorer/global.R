library(shiny)
library(rgdal)
library(leaflet)
library(rsconnect)
library(sf)

#useclasses <- c("Aquatic_Life", "Recreation", "Human_Health", "Agriculture")
#########################################################################

# Working directory will already be set if you opened the project from its directory in windows explorer
#setwd("G:/Shared drives/Projects/ERWC/WQMAP/Data_Analysis/Code/WQ_Report_Card/2020_Code_Base/Report_Card_5yr")

# Initialize program and clear workspace
rm(list = ls())

# Load Functions
sapply(list.files(pattern="[.]R$", path="./Functions/", full.names=TRUE), source)

# Enter start/end dates for the data that you want to be available in the viewer
StartDate <- ('01-01-2018') # MM-DD-YYYY This is the start date for the entire data set you want.
EndDate <- ('12-31-2022') # MM-DD-YYYY This is the end date for the entire data set you want.

#Load the monitoring stations file that was prepped in the GIS with 305(b) Segment ID information joined in
monitoringStations <- read.csv(file="./Program_Files/2023_Eagle_Monitoring_Stations_5yr.csv", 
                               header=TRUE, sep=",",stringsAsFactors=F, strip.white=T)

segments305b <- sort(unique(monitoringStations$AUID))
seg_desc <- unique(monitoringStations[c("AUID", "PortionDes")])

# WQPortal has been returning some datasets with duplicate rows, check for and remove these, they
# may not be apparent in the GIS prep if the point features were perfectly stacked on each other
monitoringStations <- monitoringStations %>% distinct()

# read in segment standards
wqStandards <- read.csv(file="./Program_Files/2023_Standards.csv", header=TRUE, stringsAsFactors=F)

# Load the dataset
watershedData <- read.csv(file="./Data/HUC_14010003_dataSheet.2023-11-13.csv", 
                          header=T,stringsAsFactors=F,strip.white=T) %>% 
  mutate()

# Load the dataset ...

# Format dates
watershedData$ActivityStartDate <- as.Date(watershedData$ActivityStartDate, tryFormats = c("%Y-%m-%d", "%m/%d/%Y")) #format as dates

# Retrieve all stations where data was actuall collected during your specified time period in the WQP database extract
Monitoring_Station_List <- unique(as.list(watershedData$MonitoringLocationIdentifier)) 

# Filter the dataset for only those stations we want to use;
# data will not be present at all sites initially downloaded from the WQP for the watershed, so pare the site list
# down to just those sites present in the dataset
monitoringStations <- monitoringStations[monitoringStations$MonitoringLocationID %in% Monitoring_Station_List,]

# remove rows with missing dates, this data can't be used
watershedData <- watershedData[!is.na(watershedData$ActivityStartDate),]

#Tidy up the data sheet to include only relevant columns
watershedData = watershedData[,c("OrganizationIdentifier", "ActivityStartDate", "ActivityStartTime.Time", "MonitoringLocationIdentifier", "ResultDetectionConditionText", "CharacteristicName", "ResultSampleFractionText", "ResultMeasureValue", "ResultMeasure.MeasureUnitCode", "ResultValueTypeName", "DetectionQuantitationLimitMeasure.MeasureValue")]

# make sure nutrients are all in correct unified unit values for standards assessment
watershedData <- standardize_units(watershedData) 

# build some lists to use in the drop-down menus

# segment_list <- c("COUCEA03_A",  "COUCEA02_A" , "COUCEA04_A" , "COUCEA05a_A", "COUCEA07b_A", "COUCEA08_A" , "COUCEA06_G",  "COUCEA06_A" , "COUCEA06_E",  "COUCEA06_D" , "COUCEA09a_A" ,"COUCEA06_C" , "COUCEA12_A", 
#                   "COUCEA09c_A" ,"COUCEA10a_A", "COUCEA06_H" , "COUCEA05c_A" ,"COUCEA06_F" , "COUCEA09a_B" ,"COUCEA09b_B" ,"COUCEA11_A" , "COUCEA09b_C" ,"COUCEA10a_B" ,"COUCEA01_A" , "COUCEA07a_A" ,"COUCEA05b_A",
#                   "COUCEA10b_A")
segment_list <- segments305b


characteristics <- wqStandards$CharacteristicNames

categories <- unique(wqStandards$Category)

indicators <- unique(wqStandards$Indicator)

useclasses <- unique(wqStandards$UseClass)

# read in the spatial datasets for the map query
# seg_shp <- readOGR("Data/ERW_streams_2020_dis_wgs.shp")
seg_shp <- st_read("Data/ERW_streams_2024_dis_clipped_to_WS.gpkg") %>% 
  st_transform(crs='epsg:4326') 
  
cat_lkup <- tibble(
  Cat = c('1a','1b','3a','3b','4a','5'),
  Cat_rename=factor(c('1a Attaining','1b Attaining with TMDL','3a No data collected',
                      '3b Insufficient data, M&E List','4a TMDL completed','5 Impaired, 303d List'))
)

seg_shp<- seg_shp %>% 
  left_join(cat_lkup)

# seg_shp <- readOGR("./Data/ERW_streams_2020_dis_wgs")
# Note: if you are offline and this file is hosted in g-drive,
# an error will return that it cannot read the data file or perhaps
# that the datafile is not a valid datasource
# seg_shp <- readOGR(dsn="./Data", layer='ERW_streams_2020_dis_wgs')

# seg_shp <- st_read("./Data/ERW_streams_2020_dis_wgs.shp")




#########################################################################################
