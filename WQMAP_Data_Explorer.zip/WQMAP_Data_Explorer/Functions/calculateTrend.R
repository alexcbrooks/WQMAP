#' Test a time-series dataset for a monotonic trend using the Seasonal Kendall Test
#' from the R package 'rkt'
#' 
#' @description Test data for appropriate use in Seasonal Kendall Test with these criteria:
#' 1) 5 years of data minimum
#' 2) first and last 1/3rd of time range includes at least 20% of data coverage (Helsel and Hirsch)
#' 3) at least 1 data point in every seasonal block, (required for package rkt() not to fail)
#' 4)  <50% censoring of data (checked prior to launching function) 
#' If these criteria are not met, the function returns an empty summary.
#' 
#' @param data Data frame of numerical water quality data.
#' 
#' @return Summary list containing slope and P-value from the Seasonal Kendall Test.  If criteria are not met, an empty summary is returned.
#' 
#' @usage calculateTrend(data)
#' 
#' @export

library(rkt)

calculateTrend = function(data){
  #Data equally distributed
  num_day_in_interval <- as.numeric(mdy(EndDate)) -  as.numeric(mdy(StartDate))+1
  date_breaks <- tibble(
    q1= mdy(StartDate) + days(0),
    q2= mdy(StartDate) +days(floor(num_day_in_interval/3)),
    q3= mdy(StartDate) +days(floor(num_day_in_interval/1.5)),
    q4= mdy(EndDate)) %>% 
    pivot_longer(cols=c(q1:q4),values_to='datebreaks') %>% 
    dplyr::select(-name)
  
  pct_data_by_bin<- data %>% 
    mutate(bin= factor(cut(ActivityStartDate, breaks = date_breaks$datebreaks,include.lowest=TRUE))) %>% 
    group_by(bin,.drop=FALSE) %>% 
    tally() %>% 
    arrange(bin) %>% 
    dplyr::mutate(pct_tot = n/sum(n)) 
   
  equaldatadist <- FALSE  #assume data does not meet criteria until tested
  if (length(pct_data_by_bin$bin) >= 3 & min(pct_data_by_bin$pct_tot)>0) { #test to see if there are data points in each 1/3, then see if minumum 20% in each third
    if (pct_data_by_bin[1,3] & pct_data_by_bin[3,3] >= 0.2) {equaldatadist <- TRUE}
  } else {
    equaldatadist <- FALSE
  }
  
  data<- data %>% 
    mutate(
      year= year(ActivityStartDate),
      mon_num = month(ActivityStartDate),
      mon = month.abb[mon_num],
      #Seasonal blocks are currently assigned these integers here, but can be user-specified to anything
      #Dec-Feb 1=winter, Mar-May 2=spring, June-Aug 3=summer, Sep-Nov 4=fall
      seas = case_when(
        mon_num %in% c(12,1,2) ~ 1,
        mon_num %in% c(3:5) ~ 2,
        mon_num %in% c(6:8) ~ 3,
        mon_num %in% c(9:11) ~ 4
      )
    ) %>% 
    arrange(ActivityStartDate)
  
  #does data meet all the criteria? if data is inadequate, return an empty summary
  if (equaldatadist == FALSE ) {
    slope  <- -9999
    pvalue <- -9999
  } else {
    #perform seasonal kendal test
    seas_test <- rkt(data$year, data$ResultMeasureValue, data$seas, rep="m")
    if (is.numeric(seas_test$sl) == TRUE) {  #if the test fails, all values will be NA
      if (seas_test$sl <= 1) {         # record results with all significance levels 
        slope  <- seas_test$B
        pvalue <- seas_test$sl
      } else{
        slope  <- -9999
        pvalue <- -9999
      }
    } else{
      slope  <- -9999
      pvalue <- -9999
    }
  }
  Trend_5yr <- c(slope, pvalue)
  return(Trend_5yr)
}

