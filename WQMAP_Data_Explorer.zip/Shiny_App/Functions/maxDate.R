#' Find date of maximum data value
#' 
#' @description Find date on which maximum value occurred. 
#' 
#' @param numeric_data The data frame produced by the retrieveNumericalData function. 
#'   The data frame contains the ActivityStartDate and ResultMeasureValue columns.
#' 
#' @return Date on which maximum value occurred of type character.
#'
#' @usage maxDate(characteristicNames, Units, valueType, Maximum)  
#' 
#' @export

maxDate = function(numeric_data){
  dateOfMax <-  numeric_data %>% 
    slice_max(ResultMeasureValue) %>% 
    pull(ActivityStartDate) %>% 
    as.character(.)
    

  return(dateOfMax)
}
