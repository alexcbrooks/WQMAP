#' Retrieve site meta data from the Water Quality Portal
#' 
#' @description Retrieves site meta data from the Water Quality Portal for a specified HUC8 watershed for a desired time period.
#' Enables matching sites with WQCD segments
#'   
#' 
#' @param HUC8 An 8-digit number corresponding to the HUC watershed classification system.
#' 
#' @return CSV of water quality site metadata for all sites with water quality data. 
#' 
#' @usage getDataByHUC8(HUC8)
#' 
#' @example 
#' getSitesyHUC8("14010003")


getSitesByHUC8 = function(HUC8){ #retrieve site meta data from the Water Quality Portal
  baseURL = c("https://www.waterqualitydata.us/data/Station/search?huc=", HUC8, '&siteType=Stream', '&mimeType=tsv')
  URL = URLencode(paste(baseURL, collapse=''))
  print(URL)
  Sites = read.table(paste(URL), header=TRUE, sep="\t", strip.white=TRUE, quote=NULL, comment='') #retrieve data from the Water Quality Portal
  Name = c("./Data/HUC_", HUC8, "_site_meta.", as.character(Sys.Date()),".csv") #save the data to a file
  fileName = paste(Name, collapse='')
  print(paste("Writing data file to ", getwd(), fileName, sep=""))
  write.table(Data, file = fileName, sep="\t", row.names=FALSE)
}


