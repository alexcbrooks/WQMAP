

# load data inputs and program functions
source("global.R")


server <- function(input, output, session) {
  
  #------------ SIDEBAR FILTER MENUS --------------------------#
  

  
  # # render a timeseries scatterplot with interactive data
  # output$scatterplot <- renderPlot({
  #   buildScatterplot(watershedData, input$useclass, input$indicator, input$category, input$mymap_shape_click$id, input$daterange[1], input$daterange[2])
  # })
  # 
  # # render a statistical assessment summary table with interactive data
  # output$table <- renderFormattable({
  #   getSummaryStats(watershedData, input$useclass, input$indicator, input$category, input$mymap_shape_click$id, "10-01-2014", "09-30-2019")
  # })
  # 
  #------------ END SIDEBAR MENUS -----------------------#
  
  #------------ START MAP CODE --------------------------#
  
  # Generate an interactive watershed map for user queries.  The map displays 305b segments which 
  # are clickable to help filter the analysis menus lower in the page. The map also has a toggle layer
  # that displays the current regulatory status of different stream segments.
  
  # render leaflet map with shapefile and options for basemaps
  
  factpal <- colorFactor(rainbow(27), seg_shp$AUID)
  pal<- c('#03d200','#86a77c','#b2b2b2','#ffbd15','#d28ce2','#ff3c01')
  
  newpal <- colorFactor(
    palette = pal,
    domain =seg_shp$Cat_rename,
    levels = c('1a Attaining','1b Attaining with TMDL','3a No data collected',
               '3b Insufficient data, M&E List','4a TMDL completed','5 Impaired, 303d List')
  )
  bounds <- st_bbox(seg_shp)
  
  output$mymap <- renderLeaflet(
    leaflet(data = seg_shp, options = leafletOptions(minZoom = 9)) %>%
      # next 3 lines require internet connection when testing
      addProviderTiles("Esri.WorldTopoMap", group = "Topo") %>%
      addProviderTiles("Esri.WorldImagery", group = "Imagery") %>%
      addProviderTiles(providers$Stamen.Terrain, group = "Terrain") %>%
      # add polyline layer with individual segments
      addPolylines(layerId = ~AUID,label = ~DESC, weight = 3, group = "Segments (Selectable)", color = ~factpal(AUID),
                   highlightOptions = highlightOptions(color = "mediumseagreen",opacity = 1.0,weight = 3,bringToFront = TRUE)) %>%
      # add polyline layer with regulatory status codes
      addPolylines(label = ~DESC, weight = 3, group = "Impairment (View only)", fillOpacity = 1, color = ~newpal(Cat_rename),
                   highlightOptions = highlightOptions(color = "mediumseagreen",opacity = 1.0,weight = 3,bringToFront = TRUE)) %>%
      # # set boundaries for viewing
      # setMaxBounds( lng1 = bounds[1,1] - 1
      #               , lat1 = bounds[2,1] - 1
      #               , lng2 = bounds[1,2] + 1
      #               , lat2 = bounds[2,2] + 1) %>% 
      # Layers control
      addLayersControl(
        baseGroups = c("Topo", "Imagery", "Terrain"),
        overlayGroups = c("Segments (Selectable)", "Impairment (View only)"),
        options = layersControlOptions(collapsed = FALSE)) %>% 
      leaflet::addLegend(
        title = "Regulatory status",
        colors=pal,labels = c('1a - Attaining','1b Attaining with TMDL','3a No data collected',
                   '3b Insufficient data, M&E List','4a TMDL completed','5 Impaired, 303d List'),position='bottomright') %>% 
      hideGroup(group = "Impairment (View only)")  
    #------------END MAP--------------------------#
  )
  
  
  
  # Select a water quality assessment segment by map shape click, return text to use for filtering drop-downs
  observeEvent(input$mymap_shape_click, {
    click = input$mymap_shape_click
    seg = input$mymap_shape_click$id
    
    updateSelectInput(inputId ='segment_id', selected=seg)
  })
  
  # Display portion text description once a segment has been selected
  # Select a water quality assessment segment by map shape click, return text to use for filtering drop-downs
  observe({
    seg_AUID <- input$segment_id
    seg_description <- seg_desc$PortionDes[seg_desc$AUID==seg_AUID]
    if(is.null(seg_AUID))
      output$temp_desc <- renderText({
        "No segment selected. Choose a segment to initiate program."})
    else
      output$temp_desc <- renderText({
        seg_description
      })
    
  })
  
  # Parameter category select menu
  df0 <- eventReactive(input$useclass,{
    wqStandards %>% filter(UseClass %in% input$useclass)
  })
  

  output$param_category <- renderUI({
    selectInput("param_category","Choose a water quality category",sort(unique(df0()$Category)))
  })
  
    # Water Quality Parameter select menu
  df1 <- eventReactive(input$param_category,{
    df0() %>% filter(Category %in% input$param_category)
  })
  

  output$wq_parameter <- renderUI({
    selectInput("wq_parameter","Choose a single parameter of interest to activate plots",sort(unique(df1()$Indicator)))
  })
  
  # render a seasonal boxplot with interactive data
  output$boxplot <- renderPlot({
    print(input$segment_id)
    print(input$useclass)
    print(input$param_category)
    print(input$wq_parameter)
    print(input$segment_id)
    print( input$daterange[1])
    print(input$daterange[2])
    buildBoxplot(watershedData, input$useclass, input$wq_parameter, input$param_category, input$segment_id, input$daterange[1], input$daterange[2])
  })
  
  # render a timeseries scatterplot with interactive data
  output$scatterplot <- renderPlot({
    buildScatterplot(watershedData, input$useclass, input$wq_parameter, input$param_category, input$segment_id, input$daterange[1], input$daterange[2])
  })
  
  # # render a statistical assessment summary table with interactive data
  # output$table <- renderFormattable({
  #   getSummaryStats(watershedData, input$useclass, input$wq_parameter, input$param_category,  input$segment_id, input$daterange[1], input$daterange[2])
  # })

  
}

# USER INTERFACE

ui <- fluidPage(
  
  titlePanel("Water Quality Explorer"),
  
  fluidRow(
    column(3,
           
           h5("Select a stream segment on the map or in the menu below to begin."),
           # Segment drop down selectbox
           selectInput(inputId = "segment_id",
                       label = "Stream regulatory segment",
                       segment_list),
           # Display the segment's narrative geographic description
           tags$em(textOutput("temp_desc")),
           # Instructions for remaining filters
           h5("Choose a single water quality parameter to activate plots and assessments"),
           # Use Class select box
           selectInput(inputId = "useclass",
                       label = "Use Class",
                       useclasses),
           # Parameter category select box, automatically filtered by available categories for this segment
           uiOutput(outputId="param_category"),
           # Parameter select box, automatically filtered by available parameters
           uiOutput(outputId="wq_parameter"),
           # Date range select 
           # TODO: change this to a slider?
           dateRangeInput(inputId = "daterange",
                          label = "Date range",
                          # start = "2014-10-01",
                          start=min(watershedData$ActivityStartDate, na.rm=T),
                          # end = "2019-09-30",
                          end=max(watershedData$ActivityStartDate, na.rm=T),
                          # min = "1988-10-01",
                          # max = "2019-09-30",
                          min=min(watershedData$ActivityStartDate, na.rm=T),
                          max=max(watershedData$ActivityStartDate, na.rm=T),
                          format = "mm-dd-yyyy")
    ),
    
    column(9,
           
           leaflet::leafletOutput(
             outputId = "mymap",
             height = 600
           )
    )
  ),
  
  
  textOutput("temp"),
  
  tags$head(tags$style("#temp{color: black;
                                 font-size: 18px;
                                 font-style: bold;
                                 }")
  ),
  # format sidebar with inputs and output table 
  # fluidRow(
  #   column(4,
  #          h4("Select a segment, date range, use class, category, and parameter to begin.  
  #      Select a segment by clicking on the map above and select other parameters using the drop down menus.  
  #      Segment assessment table is generated using 5 years of data, as per EPA regulations, and will not reflect date range changes.
  #      Plots showing historical concentration trends can be generated by altering the date range.")
  #   ),
  #   column(4,
  #          dateRangeInput(inputId = "daterange",
  #                         label = "Choose a date range",
  #                         start = "2014-10-01",
  #                         end = "2019-09-30",
  #                         min = "1988-10-01",
  #                         max = "2019-09-30",
  #                         format = "mm-dd-yyyy"),
  #          
  #          # define use class
  #          selectInput(inputId = "useclass",
  #                      label = "Use Class",
  #                      useclasses)
  #   ),
  #   column(4,
  #          uiOutput("category"),
  #          uiOutput("indicator"))
  # ),
  
  fluidRow(
    column(4,
           formattableOutput("table"),
           h6("* Hardness-based standards are dynamically calculated using temperature and hardness data collected from the past five years.  
       Calculated standard on this web app may differ from the regulatory standard and the standard reflected in the plots if date range extends beyond last 5 years.
       \n**Blue trendline in scatterplot is fitted with a LOESS smooth function.")
    ),
    # format columns
    column(4, 
           plotOutput("boxplot")
    ),
    column(4,
           plotOutput("scatterplot")      
    )
  )
)

#------------------------------------------------------------------------------------------------------#
# LAUNCH APP

shinyApp(ui = ui, server = server)
